from sys import intern


small  = float(input('hoeveel small pizza wil je? '))
medium = float(input('hoeveel medium pizza wil je? '))
larg   = float(input('hoeveel larg pizza wil je? '))

smallpizza  = 5.5
mediumpizza = 8.5
largpizza   = 10.5

factuur1 = ('small pizza: ')  + str((small)*(smallpizza))
factuur2 = ('medium pizza: ') + str((medium)*(mediumpizza))
factuur3 = ('larg pizza: '  ) + str((larg)*(largpizza))
totaal   ='je factuur/ totaale bedrag is: ' + str((small)*(smallpizza)+(medium)*(mediumpizza)+(larg)*(largpizza))
print(factuur1)
print(factuur2)
print(factuur3)
print(totaal)


